package com.cuzz.cache.controller;

import com.cuzz.cache.bean.Employee;
import com.cuzz.cache.service.EmployeeService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;

/**
 * @Author: cuzz
 * @Date: 2018/9/26 16:10
 * @Description:
 */
@Controller
public class EmployeeController {

    @Autowired
    EmployeeService employeeService;

    @RequestMapping(value = "/emp/getId",method = RequestMethod.GET)
    @ResponseBody
    public String getEmployee( Integer id) {
        Employee employee = employeeService.getEmployee(id);
        System.out.println("缓存中的数据："+employee.toString());
        return "运行结束！";
    }


    @PostMapping("/emp/postByReName")
    public Employee update(Employee employee) {
        return employeeService.updateEmployee(employee);
    }


    @GetMapping("/delete")
    public String delete(Integer id) {
        System.out.println("删除开始：");
        employeeService.deleteEmployee(id);
        System.out.println("删除完成");
        return "success";
    }

}
