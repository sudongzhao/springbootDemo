package com.cuzz.cache.mapper;

import org.apache.ibatis.annotations.Mapper;

/**
 * @Author: cuzz
 * @Date: 2018/9/26 15:54
 * @Description:
 */
@Mapper
public interface DepartmentMapper {
}
