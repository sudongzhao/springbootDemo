package com.itheima;

import com.itheima.code.build.TemplateBuilder;

/****
 * @Author:sudongzhao
 * @Description:
 * @Date 2022/5/17 23:43
 *****/
public class CodeApplication {

    public static void main(String[] args) {
        //调用该方法即可
        TemplateBuilder.builder();
    }
}
