package com.dongzhao.springboot01;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Springboot01ApplicationTests {

    @Test
    void contextLoads() {
    }

}
