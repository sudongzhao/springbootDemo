package com.dongzhao.springboot01.entity.common;

import lombok.Data;

import java.io.Serializable;

@Data
public class ReturnResult<T> implements Serializable {

    //状态码
    private Integer code;
    //提示信息
    private String message;
    //返回数据
    private T data;

}
