package com.dongzhao.springboot01.controller;

import com.dongzhao.springboot01.common.ReturnResultUtils;
import com.dongzhao.springboot01.entity.Singer;
import com.dongzhao.springboot01.entity.common.PageInfo;
import com.dongzhao.springboot01.entity.common.ReturnResult;
import com.dongzhao.springboot01.service.SingerService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Lazy;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.*;


import java.util.List;

@RestController
@RequestMapping(value = "/singer")
public class SingerController {

    @Autowired
    @Lazy
    private SingerService singerService;
    
    /**
     * 查找所有的明星
     */
    @GetMapping(value = "/getSingerAll")
    public ReturnResult<List<Singer>> findSingerAll(){
        List<Singer> singerAll = singerService.findSingerAll();
        return ReturnResultUtils.returnSuccess(singerAll);
    }

    /**
     * 根据id查找明星
     */
    @GetMapping(value = "/getSingerById/{id}")
    public ReturnResult<Singer> findSingetById(@PathVariable(value = "id")Integer id){
        Singer singer = singerService.findById(id);
        return ReturnResultUtils.returnSuccess(singer);
    }

    /**
     * 添加歌手
     */
    @PostMapping(value = "/addSinger",consumes = MediaType.APPLICATION_JSON_VALUE)
    public ReturnResult addSinger(@RequestBody Singer singer){
        singerService.add(singer);
        return ReturnResultUtils.returnSuccess();
    }

    /**
     * 修改歌手
     */
    @PutMapping(value = "/updateSinger/{id}")
    public ReturnResult updateSinger(@PathVariable(value = "id") Long id,@RequestBody Singer singer){
        singer.setId(id);
        singerService.updateSinger(singer);
        return ReturnResultUtils.returnSuccess();
    }

    /**
     * 删除歌手
     * @param id
     * @return
     */
    @DeleteMapping(value = "/deleteSinger/{id}")
    public ReturnResult deleteSinger(@PathVariable(value = "id") Integer id){
        singerService.deleteSinger(id);
        return ReturnResultUtils.returnSuccess();
    }

    @PostMapping(value = "/findSingerList")
    public ReturnResult<List<Singer>> findSingerList(@RequestBody Singer singer){
        List<Singer> singerList = singerService.findList(singer);
        return ReturnResultUtils.returnSuccess(singerList);
    }

    @GetMapping(value = "/findSingerPage/{page}/{size}")
    public ReturnResult<PageInfo<Singer>> findPage(@PathVariable(value = "page") Integer page,
                         @PathVariable(value = "size") Integer size){
        PageInfo<Singer> singerOfPage = singerService.findSingerOfPage(page, size);
        return ReturnResultUtils.returnSuccess(singerOfPage);
    }

}
