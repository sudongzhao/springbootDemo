package com.dongzhao.springboot01.service.impl;

import com.dongzhao.springboot01.dao.SingerMapper;
import com.dongzhao.springboot01.entity.Singer;
import com.dongzhao.springboot01.entity.common.PageInfo;
import com.dongzhao.springboot01.service.SingerService;
import com.github.pagehelper.PageHelper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;
import tk.mybatis.mapper.entity.Example;

import java.util.List;

@Service
public class SingerServiceImpl implements SingerService {

    @Autowired
    private SingerMapper singerMapper;

    @Override
    public List<Singer> findSingerAll() {
        return singerMapper.selectAll();
    }

    @Override
    public Singer findById(Integer id) {
        return singerMapper.selectByPrimaryKey(id);
    }

    @Override
    public int add(Singer singer) {
        return singerMapper.insertSelective(singer);
    }

    @Override
    public int updateSinger(Singer singer) {
        return singerMapper.updateByPrimaryKeySelective(singer);
    }

    @Override
    public int deleteSinger(Integer id) {
        return singerMapper.deleteByPrimaryKey(id);
    }

    @Override
    public List<Singer> findList(Singer singer) {
        //自定义条件
        Example example = new Example(Singer.class);
        Example.Criteria criteria = example.createCriteria();
        if (singer!=null){
            if (!StringUtils.isEmpty(singer.getName())){
                criteria.andLike("name","%"+singer.getName()+"%");
            }
        }
        return singerMapper.selectByExample(example);
    }

    @Override
    public PageInfo<Singer> findSingerOfPage(Integer page, Integer size) {
        PageHelper.startPage(page,size);
        List<Singer> singers = singerMapper.selectAll();
        return new PageInfo<Singer>(singers);
    }

}
