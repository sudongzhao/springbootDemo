package com.dongzhao.springboot01.service;

import com.dongzhao.springboot01.entity.Singer;
import com.dongzhao.springboot01.entity.common.PageInfo;


import java.util.List;

public interface SingerService {
    /**
     * 查找歌手所有数据
     */
    List<Singer> findSingerAll();

    /**
     * 根据id查找歌手
     */
    Singer findById(Integer id);

    /**
     * 添加歌手
     * @return
     */
    int add(Singer singer);

    /**
     * 修改歌手
     * @return
     */
    int updateSinger(Singer singer);

    /**
     * 删除歌手
     * @return
     */
    int deleteSinger(Integer id);

    /**
     * 根据条件获取歌手
     * @param singer
     * @return
     */
    List<Singer> findList(Singer singer);

    /**
     * 分页查询
     * @param page
     * @param size
     * @return
     */
    PageInfo<Singer> findSingerOfPage(Integer page, Integer size);
}
