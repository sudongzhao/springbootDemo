package com.dongzhao.springboot01.dao;

import com.dongzhao.springboot01.entity.Singer;
import tk.mybatis.mapper.common.Mapper;

public interface SingerMapper extends Mapper<Singer> {

}
