package com.dongzhao.springboot01.entity;

import lombok.Data;

import javax.persistence.Column;
import javax.persistence.Id;
import javax.persistence.Table;
import java.util.Date;
import java.io.Serializable;

/**
 * 歌手实体类
 *
 * @author sudongzhao
 * @since 2022-05-13 21:08:15
 */
@Data
@Table(name = "singer")
public class Singer implements Serializable {
    private static final long serialVersionUID = 562917131337833241L;

    @Id
    private Long id;

    @Column(name = "name")
    private String name;

    @Column(name = "sex")
    private Integer sex;

    @Column(name = "pic")
    private String pic;

    @Column(name = "birth")
    private Date birth;

    @Column(name = "location")
    private String location;

    @Column(name = "introduction")
    private String introduction;

}
