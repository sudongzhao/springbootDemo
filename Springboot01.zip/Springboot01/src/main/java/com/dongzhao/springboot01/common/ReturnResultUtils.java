package com.dongzhao.springboot01.common;

import com.dongzhao.springboot01.contant.ReturnResultContant;
import com.dongzhao.springboot01.entity.common.ReturnResult;
import sun.management.snmp.jvminstr.JvmThreadInstanceTableMetaImpl;

import java.util.List;

public class ReturnResultUtils {
    /**
     * 成功，不带数据
     * @return 返回状态码与状态信息
     */
    public static ReturnResult returnSuccess(){
        ReturnResult returnResult = new ReturnResult();
        returnResult.setCode(ReturnResultContant.SUCCESS);
        returnResult.setMessage("success");
        return returnResult;
    }

    /**
     * 成功，返回数据
     * @return 返回状态码，状态信息与数据
     */
    public static ReturnResult returnSuccess(Object data){
        ReturnResult returnResult = new ReturnResult();
        returnResult.setCode(ReturnResultContant.SUCCESS);
        returnResult.setMessage("success");
        returnResult.setData(data);
        return returnResult;
    }

    /**
     * 失败
     * @return 返回状态码与状态信息
     */
    public static ReturnResult returnFail(){
        ReturnResult returnResult = new ReturnResult();
        returnResult.setCode(ReturnResultContant.FAIL);
        returnResult.setMessage("Fail");
        return returnResult;

    }

}
