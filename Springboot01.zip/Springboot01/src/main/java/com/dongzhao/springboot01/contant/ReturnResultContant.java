package com.dongzhao.springboot01.contant;

public class ReturnResultContant {

    //success
    public static final int SUCCESS=200;

    //FAIL
    public static final int FAIL=400;
}
