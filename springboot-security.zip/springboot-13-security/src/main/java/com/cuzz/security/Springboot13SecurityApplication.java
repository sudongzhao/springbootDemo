package com.cuzz.security;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Springboot13SecurityApplication {

	public static void main(String[] args) {
		SpringApplication.run(Springboot13SecurityApplication.class, args);
	}
}
