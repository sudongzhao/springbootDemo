package com.example.demo.Service.impl;

import com.example.demo.Dao.UserDao;
import com.example.demo.Service.UserService;
import com.example.demo.entity.User;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class UserServiceImpl implements UserService {
    private UserDao userDao;

    @Override
    public List<User> findAll() {
        return userDao.findAll();
    }
}
