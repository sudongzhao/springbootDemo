package com.example.demo.entity;


import lombok.Data;
import org.hibernate.annotations.Proxy;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;

@Proxy(lazy = false)
@Data
@Entity(name = "t_user")
public class User {

    @Id // 表明id
    @GeneratedValue   //  自动生成
    private Long id;

    private String name;

}
